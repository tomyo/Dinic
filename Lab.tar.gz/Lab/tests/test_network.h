#ifndef TEST_NETWORK_H
#define TEST_NETWORK_H

#include <check.h>

Suite *network_suite(void);

void network_memory_test(void);

#endif

