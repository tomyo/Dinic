#ifndef TEST_EDGE_H
#define TEST_EDGE_H

#include <check.h>

Suite *edge_suite(void);

void edge_memory_test(void);

#endif
