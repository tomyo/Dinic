#ifndef TEST_DINIC_H
#define TEST_DINIC_H

#include <check.h>

Suite *dinic_suite(void);

void dinic_memory_test(void);

#endif
