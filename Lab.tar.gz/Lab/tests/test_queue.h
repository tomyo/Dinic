#ifndef TEST_QUEUE_H
#define TEST_QUEUE_H

#include <check.h>

Suite *queue_suite(void);

void queue_memory_test(void);

#endif
