#ifndef TEST_SLIST_H
#define TEST_SLIST_H

#include <check.h>

Suite *slist_suite(void);

void list_memory_test(void);

#endif
