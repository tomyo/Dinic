#ifndef TEST_NETWORK_H
#define TEST_NETWORK_H

#include <check.h>

Suite *hash_table_suite(void);

void hash_table_memory_test(void);

#endif

